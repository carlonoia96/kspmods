KSP Toolbar Plugin
==================

This is a plugin for [Kerbal Space Program] that adds a common API for a buttons toolbar.
Third-party plugin authors may use the API to add their buttons to the toolbar.

For more information, please visit the [Forums Feedback Thread].

[Kerbal Space Program]: http://www.kerbalspaceprogram.com
[Forums Feedback Thread]: http://forum.kerbalspaceprogram.com/threads/60066
